import { config } from "dotenv";
import "@testing-library/jest-dom/vitest";

config({ path: ".env.test", override: true, quiet: true });
